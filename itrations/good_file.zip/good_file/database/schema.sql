﻿-- ─────────────────────────────────────────────────────────────
-- Employee Requests / Proposals table
-- Run this in Supabase → SQL Editor (after your existing schema)
-- ─────────────────────────────────────────────────────────────

create table if not exists public.requests (
  id           uuid primary key default gen_random_uuid(),
  employee_id  uuid not null references auth.users(id) on delete cascade,
  title        text not null,
  description  text not null,
  status       text not null default 'pending'   -- 'pending' | 'in_review' | 'approved' | 'rejected'
                 check (status in ('pending', 'in_review', 'approved', 'rejected')),
  admin_note   text,                              -- reply/feedback from admin
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

-- Keep updated_at fresh on every change
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_requests_updated_at on public.requests;
create trigger trg_requests_updated_at
  before update on public.requests
  for each row execute function public.set_updated_at();

-- ── Row Level Security ──────────────────────────────────────────
alter table public.requests enable row level security;

-- Employees can see only their own requests
drop policy if exists "employees select own requests" on public.requests;
create policy "employees select own requests"
  on public.requests for select
  using (auth.uid() = employee_id);

-- Employees can insert their own requests
drop policy if exists "employees insert own requests" on public.requests;
create policy "employees insert own requests"
  on public.requests for insert
  with check (auth.uid() = employee_id);

-- NOTE: There is no "admin select all" policy here because your admin
-- account is a hardcoded login (not a Supabase auth user), so the app
-- talks to this table using the service_role key (supabase_admin),
-- which bypasses RLS entirely. That's the same pattern already used
-- for the admin employee list in /dashboard/admin.
-- ── GALLERY PHOTOS ─────────────────────────────────────────────
create table gallery_photos (
  id uuid primary key default gen_random_uuid(),
  image_url text not null,
  storage_path text not null,   -- path inside the storage bucket, needed to delete later
  caption text not null default '',
  uploaded_by uuid references profiles(id),
  created_at timestamptz default now()
);

alter table gallery_photos enable row level security;

create policy "gallery_select_all" on gallery_photos
  for select using (true);

create policy "gallery_insert_admin_only" on gallery_photos
  for insert with check (is_admin());

create policy "gallery_delete_admin_only" on gallery_photos
  for delete using (is_admin());

  -- ═══════════════════════════════════════════════════════════════
-- COURSES TABLE  (additive — safe to run on existing schema)
-- ═══════════════════════════════════════════════════════════════
create table if not exists courses (
  id            uuid primary key default gen_random_uuid(),
  title         text not null,
  description   text,
  price         integer not null default 0,
  original_price integer,
  duration      text,
  schedule      text,
  mode          text,
  status        text not null check (status in ('live', 'coming_soon')) default 'coming_soon',
  tags          text[] default '{}',
  cta_link      text default '',
  cta_label     text default 'View Course Details',
  is_active     boolean not null default true,
  created_at    timestamptz default now()
);

-- RLS
alter table courses enable row level security;

-- Public can only see active courses
create policy "courses_select_public" on courses
  for select using (is_active = true);

-- Admin can do everything (reuses your existing is_admin() function)
create policy "courses_admin_all" on courses
  for all using (is_admin()) with check (is_admin());