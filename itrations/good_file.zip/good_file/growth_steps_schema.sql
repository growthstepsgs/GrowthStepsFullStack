-- ═══════════════════════════════════════════════════════════════
-- GROWTH STEPS — COMPLETE SUPABASE SCHEMA
-- Run this entire file in Supabase SQL Editor
-- Safe to re-run on existing databases
-- ═══════════════════════════════════════════════════════════════

-- ── 1. HELPER FUNCTIONS ───────────────────────────────────────

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create or replace function public.is_admin()
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
begin
  return exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
end;
$$;

-- Auto-create profile when a new auth.users row is inserted
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name, role, email)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', ''),
    'student',
    new.email
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

-- ── 2. PROFILES ───────────────────────────────────────────────

create table if not exists public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  full_name  text,
  email      text,
  role       text not null default 'student'
               check (role in ('admin', 'employee', 'student')),
  created_at timestamptz not null default now()
);

-- Trigger: auto-insert profile on signup
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- RLS
alter table public.profiles enable row level security;

drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own"
  on public.profiles for select
  using (auth.uid() = id);

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own"
  on public.profiles for update
  using (auth.uid() = id);

drop policy if exists "profiles_admin_all" on public.profiles;
create policy "profiles_admin_all"
  on public.profiles for all
  using (is_admin()) with check (is_admin());

-- ── 3. REQUESTS (Employee Proposals) ──────────────────────────

create table if not exists public.requests (
  id           uuid primary key default gen_random_uuid(),
  employee_id  uuid not null references auth.users(id) on delete cascade,
  title        text not null,
  description  text not null,
  status       text not null default 'pending'
                 check (status in ('pending', 'in_review', 'approved', 'rejected')),
  admin_note   text,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

-- Keep updated_at fresh
drop trigger if exists trg_requests_updated_at on public.requests;
create trigger trg_requests_updated_at
  before update on public.requests
  for each row execute function public.set_updated_at();

-- RLS
alter table public.requests enable row level security;

drop policy if exists "requests_select_own" on public.requests;
create policy "requests_select_own"
  on public.requests for select
  using (auth.uid() = employee_id);

drop policy if exists "requests_insert_own" on public.requests;
create policy "requests_insert_own"
  on public.requests for insert
  with check (auth.uid() = employee_id);

-- ── 4. GALLERY PHOTOS ─────────────────────────────────────────

create table if not exists public.gallery_photos (
  id           uuid primary key default gen_random_uuid(),
  image_url    text not null,
  storage_path text not null,
  caption      text not null default '',
  uploaded_by  uuid references public.profiles(id),
  created_at   timestamptz default now()
);

-- RLS
alter table public.gallery_photos enable row level security;

drop policy if exists "gallery_select_all" on public.gallery_photos;
create policy "gallery_select_all"
  on public.gallery_photos for select using (true);

drop policy if exists "gallery_insert_admin_only" on public.gallery_photos;
create policy "gallery_insert_admin_only"
  on public.gallery_photos for insert with check (is_admin());

drop policy if exists "gallery_delete_admin_only" on public.gallery_photos;
create policy "gallery_delete_admin_only"
  on public.gallery_photos for delete using (is_admin());

-- ── 5. COURSES ────────────────────────────────────────────────

create table if not exists public.courses (
  id             uuid primary key default gen_random_uuid(),
  title          text not null,
  description    text,
  price          integer not null default 0,
  original_price integer,
  duration       text,
  schedule       text,
  mode           text,
  status         text not null check (status in ('live', 'coming_soon')) default 'coming_soon',
  tags           text[] default '{}',
  cta_link       text default '',
  cta_label      text default 'View Course Details',
  is_active      boolean not null default true,
  slug           text unique,
  trainer_name   text,
  trainer_avatar text,
  trainer_bio    text,
  trainer_tags   text[] default '{}',
  outcomes       text[] default '{}',
  curriculum     jsonb default '[]',
  projects       jsonb default '[]',
  benefits       jsonb default '[]',
  faq            jsonb default '[]',
  pricing_tiers  jsonb default '[]',
  hero_benefits  text[] default '{}',
  hero_stats     jsonb default '[]',
  created_at     timestamptz default now()
);

-- RLS
alter table public.courses enable row level security;

drop policy if exists "courses_select_public" on public.courses;
create policy "courses_select_public"
  on public.courses for select using (is_active = true);

drop policy if exists "courses_admin_all" on public.courses;
create policy "courses_admin_all"
  on public.courses for all using (is_admin()) with check (is_admin());

-- ── 6. ENROLLMENTS (Per-Course Student Access) ────────────────

create table if not exists public.enrollments (
  id           uuid primary key default gen_random_uuid(),
  student_id   uuid not null references auth.users(id) on delete cascade,
  course_id    uuid not null references public.courses(id) on delete cascade,
  status       text not null default 'pending'
                 check (status in ('pending', 'approved', 'rejected')),
  created_at   timestamptz default now(),
  approved_at  timestamptz,
  unique(student_id, course_id)
);

-- RLS
alter table public.enrollments enable row level security;

drop policy if exists "enrollments_select_own" on public.enrollments;
create policy "enrollments_select_own"
  on public.enrollments for select using (auth.uid() = student_id);

drop policy if exists "enrollments_insert_own" on public.enrollments;
create policy "enrollments_insert_own"
  on public.enrollments for insert with check (auth.uid() = student_id);

-- ── 7. COURSE CONTENTS (Videos, PPTs, Assignments) ────────────

create table if not exists public.course_contents (
  id          uuid primary key default gen_random_uuid(),
  course_id   uuid not null references public.courses(id) on delete cascade,
  title       text not null,
  type        text not null check (type in ('video', 'ppt', 'assignment', 'certificate')),
  url         text,
  sort_order  integer default 0,
  created_at  timestamptz default now()
);

-- RLS
alter table public.course_contents enable row level security;

drop policy if exists "course_contents_select_all" on public.course_contents;
create policy "course_contents_select_all"
  on public.course_contents for select using (true);

drop policy if exists "course_contents_admin_all" on public.course_contents;
create policy "course_contents_admin_all"
  on public.course_contents for all using (is_admin()) with check (is_admin());

-- ── 8. REVIEWS ────────────────────────────────────────────────

create table if not exists public.reviews (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references auth.users(id) on delete cascade,
  user_name    text,
  rating       integer not null check (rating between 1 and 5),
  content      text not null,
  is_pinned    boolean not null default false,
  created_at   timestamptz not null default now()
);

-- RLS
alter table public.reviews enable row level security;

drop policy if exists "reviews_select_all" on public.reviews;
create policy "reviews_select_all"
  on public.reviews for select using (true);

drop policy if exists "reviews_insert_own" on public.reviews;
create policy "reviews_insert_own"
  on public.reviews for insert with check (auth.uid() = user_id);

drop policy if exists "reviews_delete_admin" on public.reviews;
create policy "reviews_delete_admin"
  on public.reviews for delete using (is_admin());

drop policy if exists "reviews_update_admin" on public.reviews;
create policy "reviews_update_admin"
  on public.reviews for update using (is_admin());

-- ── 9. DAILY PROGRESS ─────────────────────────────────────────

create table if not exists public.daily_progress (
  id                uuid primary key default gen_random_uuid(),
  employee_id       uuid not null references auth.users(id) on delete cascade,
  work_date         date not null default current_date,
  tasks_completed   text not null,
  hours_worked      numeric(4,1) not null check (hours_worked > 0 and hours_worked <= 24),
  blockers          text,
  plans_tomorrow    text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

-- Unique constraint: one entry per employee per day
create unique index if not exists idx_daily_progress_employee_date
  on public.daily_progress (employee_id, work_date);

-- Trigger for updated_at
drop trigger if exists trg_daily_progress_updated_at on public.daily_progress;
create trigger trg_daily_progress_updated_at
  before update on public.daily_progress
  for each row execute function public.set_updated_at();

-- RLS
alter table public.daily_progress enable row level security;

drop policy if exists "daily_progress_select_own" on public.daily_progress;
create policy "daily_progress_select_own"
  on public.daily_progress for select
  using (auth.uid() = employee_id);

drop policy if exists "daily_progress_insert_own" on public.daily_progress;
create policy "daily_progress_insert_own"
  on public.daily_progress for insert
  with check (auth.uid() = employee_id);

drop policy if exists "daily_progress_update_own" on public.daily_progress;
create policy "daily_progress_update_own"
  on public.daily_progress for update
  using (auth.uid() = employee_id);

drop policy if exists "daily_progress_admin_all" on public.daily_progress;
create policy "daily_progress_admin_all"
  on public.daily_progress for all using (is_admin());



















-- Kill the trigger that is blocking every new signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Optional: backfill profiles for any existing auth users that somehow missed it
INSERT INTO public.profiles (id, full_name, email, role)
SELECT 
    u.id,
    COALESCE(u.raw_user_meta_data->>'full_name', u.raw_user_meta_data->>'name', ''),
    u.email,
    'student'
FROM auth.users u
LEFT JOIN public.profiles p ON u.id = p.id
WHERE p.id IS NULL
ON CONFLICT (id) DO NOTHING;