﻿-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
-- GROWTH STEPS . FULL SUPABASE SCHEMA (clean install)
-- Run this in Supabase SQL Editor. Safe to re-run . it drops
-- and recreates everything from scratch.
-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

-- Clean slate (safe even if these don't exist yet)
drop table if exists progress_logs cascade;
drop table if exists employee_requests cascade;
drop table if exists calendar_events cascade;
drop table if exists profiles cascade;
drop function if exists handle_new_user cascade;
drop function if exists is_admin cascade;

-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
-- 1. PROFILES â”€â”€ extends Supabase auth.users with role + name
-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null check (role in ('admin', 'employee', 'student')) default 'student',
  created_at timestamptz default now()
);

-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
-- 2. CALENDAR EVENTS
-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
create table calendar_events (
  id uuid primary key default gen_random_uuid(),
  event_date date not null unique,
  color text not null default '#6366F1',
  note text default '',
  created_by uuid references profiles(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
-- 3. REQUESTS ("needs") . submitted by employees/students,
--    reviewed by admin
-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
create table employee_requests (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references profiles(id) on delete cascade,
  title text not null,
  description text not null,
  status text not null check (status in ('pending', 'approved', 'rejected')) default 'pending',
  admin_note text default '',
  created_at timestamptz default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references profiles(id)
);

-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
-- 4. DAILY PROGRESS LOGS (employees only)
-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
create table progress_logs (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references profiles(id) on delete cascade,
  log_date date not null,
  summary text not null,
  created_at timestamptz default now(),
  unique (employee_id, log_date)
);

-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
-- HELPER: is the current user an admin?
-- security definer = bypasses RLS internally, so it can safely
-- check the profiles table without recursion issues.
-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
create or replace function is_admin()
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from profiles where id = auth.uid() and role = 'admin'
  );
$$;

-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
-- AUTO-CREATE PROFILE ON SIGNUP (defaults to 'student')
-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
create or replace function handle_new_user()
returns trigger
language plpgsql
security definer
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.email), 'student');
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();

-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
-- ROW LEVEL SECURITY
-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

alter table profiles enable row level security;
alter table calendar_events enable row level security;
alter table employee_requests enable row level security;
alter table progress_logs enable row level security;

-- PROFILES
create policy "profiles_select_own_or_admin" on profiles
  for select using (id = auth.uid() or is_admin());

create policy "profiles_update_own" on profiles
  for update using (id = auth.uid());

-- CALENDAR: anyone logged in can view; only admin can write
create policy "calendar_select_all" on calendar_events
  for select using (true);

create policy "calendar_insert_admin_only" on calendar_events
  for insert with check (is_admin());

create policy "calendar_update_admin_only" on calendar_events
  for update using (is_admin());

create policy "calendar_delete_admin_only" on calendar_events
  for delete using (is_admin());

-- REQUESTS: owner or admin can see; owner creates; admin updates
create policy "requests_select_own_or_admin" on employee_requests
  for select using (employee_id = auth.uid() or is_admin());

create policy "requests_insert_own" on employee_requests
  for insert with check (employee_id = auth.uid());

create policy "requests_update_admin_only" on employee_requests
  for update using (is_admin());

-- PROGRESS LOGS: owner or admin can see; owner creates/updates own
create policy "progress_select_own_or_admin" on progress_logs
  for select using (employee_id = auth.uid() or is_admin());

create policy "progress_insert_own" on progress_logs
  for insert with check (employee_id = auth.uid());

create policy "progress_update_own" on progress_logs
  for update using (employee_id = auth.uid());

-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
-- MAKE YOUR ADMIN ACCOUNT
-- Run steps 1 and 2 separately, in order:
--
-- STEP 1: Go to /signup on your site and create an account with
--   Email:    rsvijaysarathi123@gmail.com
--   Password: v2v24123@v2v24123
--
-- STEP 2: Then come back here and run this UPDATE (uncomment it):
-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

update profiles
set role = 'admin'
where id = (select id from auth.users where email = 'rsvijaysarathi123@gmail.com');

-- To verify it worked, run:
-- select u.email, p.role from auth.users u join profiles p on p.id = u.id;
